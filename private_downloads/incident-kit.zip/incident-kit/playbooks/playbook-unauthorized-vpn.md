# Playbook: Unauthorized VPN / Remote Access (MITRE T1133)

## Erkennung
- VPN logins from new geo/IP
- Internal scans after VPN login

## Containment
1. Disable users / revoke certs
2. Block source IPs temporarily
3. Enforce MFA + posture checks

## Eradikation
- Patch VPN appliance
- Rotate shared secrets

## Recovery
- Re-issue VPN profiles
- Review least privilege
