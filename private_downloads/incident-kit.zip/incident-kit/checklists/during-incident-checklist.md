# During-Incident Checklist
- [ ] Incident Channel erstellt (#incident-YYYYMMDD)
- [ ] Incident Commander bestimmt
- [ ] Containment first (Stop the bleeding)
- [ ] Evidence sichern (logs, snapshots)
