# Playbook: Data Leak / Exfiltration (MITRE T1048)

## Erkennung
- DLP alerts, unusual egress
- Storage: mass reads/download spikes

## Containment
1. Cut egress for suspected hosts/users
2. Disable tokens/keys
3. Snapshot logs (immutable)

## Eradikation
- Close exposed buckets/endpoints
- Fix misconfigs (public ACLs, wide CORS)

## Recovery
- Verify closure + add monitoring
