# Pre-Incident Checklist
- [ ] IR Plan existiert und ist getestet
- [ ] Rollen geklärt (IC, Ops, Comms, Forensics)
- [ ] Logging: VPN, IdP, Cloud, WAF/Proxy, Endpoint
- [ ] Backups getestet (Restore drill)
