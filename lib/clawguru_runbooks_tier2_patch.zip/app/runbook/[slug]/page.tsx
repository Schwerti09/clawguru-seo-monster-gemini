// File: app/runbook/[slug]/page.tsx
import Container from "@/components/shared/Container"
import SectionTitle from "@/components/shared/SectionTitle"
import { RUNBOOKS, getRunbook, type RunbookBlock } from "@/lib/pseo"
import { notFound } from "next/navigation"

export const revalidate = 60 * 60 * 24 // 24h
export const dynamicParams = true

export async function generateStaticParams() {
  return RUNBOOKS.slice(0, 200).map((r) => ({ slug: r.slug }))
}

export async function generateMetadata({ params }: { params: { slug: string } }) {
  const r = getRunbook(params.slug)
  if (!r) return {}
  return {
    title: `${r.title} | ClawGuru Runbook`,
    description: r.summary,
    alternates: { canonical: `/runbook/${r.slug}` },
    openGraph: { title: `${r.title} | ClawGuru`, description: r.summary, type: "article" },
  }
}

function jsonLd(r: { title: string; summary: string; slug: string; steps: string[] }) {
  return {
    "@context": "https://schema.org",
    "@type": "HowTo",
    name: r.title,
    description: r.summary,
    url: `/runbook/${r.slug}`,
    step: r.steps.map((s, i) => ({ "@type": "HowToStep", position: i + 1, name: s, text: s })),
  }
}

function BlockView({ b }: { b: RunbookBlock }) {
  if (b.kind === "h2") return <h2 className="mt-8 text-xl font-semibold">{b.text}</h2>
  if (b.kind === "p") return <p className="mt-3 text-white/80">{b.text}</p>
  if (b.kind === "ul")
    return (
      <ul className="mt-3 list-disc pl-5 text-white/80 space-y-1">
        {b.items.map((it, i) => (
          <li key={i}>{it}</li>
        ))}
      </ul>
    )
  if (b.kind === "code")
    return (
      <pre className="mt-3 rounded-xl bg-black/40 p-4 overflow-x-auto text-sm">
        <code>{b.code}</code>
      </pre>
    )
  if (b.kind === "callout")
    return (
      <div
        className={`mt-4 rounded-xl border p-4 ${
          b.tone === "warn" ? "border-red-400/30 bg-red-500/10" : "border-emerald-400/30 bg-emerald-500/10"
        }`}
      >
        <div className="font-semibold">{b.title}</div>
        <div className="text-white/80 mt-1">{b.text}</div>
      </div>
    )
  return null
}

export default function RunbookPage({ params }: { params: { slug: string } }) {
  const r = getRunbook(params.slug)
  if (!r) return notFound()

  const related = RUNBOOKS.filter((x) => x.slug !== r.slug && x.tags.some((t) => r.tags.includes(t))).slice(0, 6)

  return (
    <Container className="py-12">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(jsonLd({ title: r.title, summary: r.summary, slug: r.slug, steps: r.howto.steps })),
        }}
      />
      <SectionTitle kicker="Runbook" title={r.title} subtitle={r.summary} />

      <div className="mt-6">{(r.blocks || []).map((b, i) => <BlockView key={i} b={b} />)}</div>

      <div className="mt-10 border-t border-white/10 pt-8">
        <h3 className="text-lg font-semibold">Fix‑Schritte (Kurz)</h3>
        <ol className="mt-3 list-decimal pl-5 text-white/80 space-y-2">
          {r.howto.steps.map((s, i) => (
            <li key={i}>{s}</li>
          ))}
        </ol>
      </div>

      {related.length > 0 && (
        <div className="mt-12 border-t border-white/10 pt-8">
          <h3 className="text-lg font-semibold">Related Runbooks</h3>
          <div className="mt-4 grid gap-3 md:grid-cols-2">
            {related.map((x) => (
              <a
                key={x.slug}
                href={`/runbook/${x.slug}`}
                className="rounded-xl border border-white/10 bg-white/5 p-4 hover:bg-white/10"
              >
                <div className="font-semibold">{x.title}</div>
                <div className="mt-1 text-sm text-white/70">{x.summary}</div>
              </a>
            ))}
          </div>
        </div>
      )}
    </Container>
  )
}
