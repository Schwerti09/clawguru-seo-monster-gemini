# Playbook: Ransomware (MITRE T1486)

## Erkennung
- EDR Alerts: mass file rename / encryption patterns
- SIEM: hohe Schreib-/Delete-Raten, ungewöhnliche SMB Activity

## Containment
1. Infizierte Hosts isolieren (VLAN quarantine)
2. Privileged Accounts sperren / reset
3. SMB Shares offline oder read-only

## Eradikation
- Malware entfernen (EDR remediation)
- Patch initial vector (VPN/RDP/vuln service)

## Recovery
- Backup-Integrität prüfen (offline/immutable)
- Recovery staged: critical services zuerst

## Lessons Learned
- Time-to-detect/contain messen
- Backup restore drills
