#!/usr/bin/env bash
set -euo pipefail
NAME="${1:-incident-$(date +%Y%m%d)}"
echo "[*] Create incident channel: $NAME"
echo "Slack example: slack channel create $NAME"
