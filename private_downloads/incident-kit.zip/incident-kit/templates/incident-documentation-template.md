# Incident Documentation Template
## Summary
- What happened:
- Start time:
- Detection method:
- Severity:

## Timeline (UTC)
- T0:
- T+10m:
- T+60m:

## Impact
- Systems:
- Users:
- Data:

## Actions
- Containment:
- Eradication:
- Recovery:
