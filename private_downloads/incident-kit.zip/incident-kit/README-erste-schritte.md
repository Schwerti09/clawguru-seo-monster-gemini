# INCIDENT KIT – ClawGuru

1. Playbooks durchlesen (abhängig vom Incident-Typ)
2. Battle Card ausdrucken
3. Incident-Dokument öffnen (templates/)
4. Checklisten abarbeiten
5. Postmortem nicht vergessen!
