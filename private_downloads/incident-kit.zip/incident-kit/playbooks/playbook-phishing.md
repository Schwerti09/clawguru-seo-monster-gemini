# Playbook: Phishing (MITRE T1566)

## Erkennung
- User reports, suspicious headers
- IdP: impossible travel, new device

## Containment
1. Accounts sperren, MFA reset
2. Session tokens invalidieren
3. Inbox rules / forwarding entfernen

## Eradikation
- Remove OAuth grants, malicious rules
- Rotate accessed secrets

## Recovery
- Clean MFA setup, password reset
- Tune SIEM rules
